Frame draw:
coordinate:
1016.501, -940.572, 525.712, 0,0,0
